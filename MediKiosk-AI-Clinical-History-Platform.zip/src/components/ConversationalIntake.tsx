import React, { useState, useEffect } from 'react';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  ArrowRight, 
  ArrowLeft, 
  AlertTriangle, 
  CheckCircle2, 
  HeartPulse, 
  Flame, 
  Bone, 
  Wind, 
  Activity, 
  Sparkles,
  Smile,
  Meh,
  Frown,
  Radio,
  Sliders,
  Check,
  Stethoscope
} from 'lucide-react';
import { 
  PatientProfile, 
  LanguageCode, 
  ClinicalHistoryRecord, 
  SocratesHPI, 
  DashavidhaPariksha, 
  RedFlagAlert 
} from '../types';
import { CHIEF_COMPLAINTS, DEFAULT_AYUSH_PARIKSHA, ChiefComplaintTemplate } from '../data/clinicalKnowledge';
import { UI_TEXTS } from '../data/translations';
import { speakPrompt, stopSpeech } from '../utils/speechHelper';

interface ConversationalIntakeProps {
  patient: PatientProfile;
  currentLanguage: LanguageCode;
  audioEnabled: boolean;
  onComplete: (record: Partial<ClinicalHistoryRecord>) => void;
  onRedFlagTriggered: (alert: RedFlagAlert) => void;
  onBackToProfile: () => void;
}

export const ConversationalIntake: React.FC<ConversationalIntakeProps> = ({
  patient,
  currentLanguage,
  audioEnabled,
  onComplete,
  onRedFlagTriggered,
  onBackToProfile,
}) => {
  const t = UI_TEXTS[currentLanguage] || UI_TEXTS.en;

  // Selected chief complaint
  const [selectedComplaint, setSelectedComplaint] = useState<ChiefComplaintTemplate>(
    patient.opdTrack === 'ayush' ? CHIEF_COMPLAINTS[1] : CHIEF_COMPLAINTS[0]
  );

  // Flow steps inside Intake
  // 1: Chief complaint pick, 2: SOCRATES deep dive, 3: AYUSH Pariksha (if Ayush) / Past history & Allergies, 4: Severity & Review
  const [subStep, setSubStep] = useState<number>(1);

  // SOCRATES state
  const [hpiState, setHpiState] = useState<SocratesHPI>({
    site: patient.opdTrack === 'ayush' ? 'Bilateral Knees (Janu Sandhi)' : 'Retrosternal Mid-Chest',
    onset: 'Sudden onset <2 hours',
    character: patient.opdTrack === 'ayush' ? 'Morning stiffness with crunching crepitus' : 'Crushing, heavy pressure',
    radiation: patient.opdTrack === 'ayush' ? 'Non-radiating' : 'Radiating to left arm and jaw',
    associations: patient.opdTrack === 'ayush' ? ['Morning stiffness >45 mins'] : ['Cold diaphoresis and dyspnea'],
    timing: 'Continuous with periodic worsening',
    exacerbatingFactors: 'Aggravated by physical exertion or walking',
    relievingFactors: 'Relieved slightly with rest and warm compress',
    severity: 7,
  });

  // AYUSH Dashavidha state
  const [ayushPariksha, setAyushPariksha] = useState<DashavidhaPariksha>(DEFAULT_AYUSH_PARIKSHA);

  // Allergies & Past History
  const [pastMedicalHistory, setPastMedicalHistory] = useState<string[]>([
    'Type 2 Diabetes Mellitus (since 2018)',
    'Essential Hypertension (on regular treatment)',
  ]);
  const [allergies, setAllergies] = useState<string[]>(['No known drug allergies (NKDA)']);

  // Voice recognition simulation state
  const [isListening, setIsListening] = useState(false);
  const [spokenTranscript, setSpokenTranscript] = useState('');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  // Dynamic questions for the selected complaint
  const currentQuestions = selectedComplaint.defaultQuestions;

  // Speak current question when index changes or audio enabled
  useEffect(() => {
    if (audioEnabled && subStep === 2) {
      const q = currentQuestions[currentQuestionIndex];
      if (q) {
        const textToSpeak = currentLanguage === 'hi' ? q.questionHi : q.questionEn;
        speakPrompt(textToSpeak, currentLanguage);
      }
    }
  }, [currentQuestionIndex, subStep, audioEnabled, currentLanguage]);

  // Handle voice recording simulation & Web Speech API integration
  const toggleVoiceRecording = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    setIsListening(true);
    setSpokenTranscript('सुन रहे हैं... (Listening for speech in Hindi / Indian English)...');

    // If browser supports webkitSpeechRecognition
    if (typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      try {
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        recognition.lang = currentLanguage === 'hi' ? 'hi-IN' : 'en-IN';
        recognition.interimResults = true;
        recognition.maxAlternatives = 1;

        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setSpokenTranscript(`"${transcript}"`);
          handleSpokenVoiceInput(transcript);
        };

        recognition.onerror = () => {
          simulateVoiceInput();
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognition.start();
        return;
      } catch (err) {
        console.warn('SpeechRecognition error, falling back to simulated ASR:', err);
      }
    }

    simulateVoiceInput();
  };

  const simulateVoiceInput = () => {
    setTimeout(() => {
      const simulatedResponses: Record<string, string[]> = {
        chest_pain: [
          'डॉक्टर साहब, सीने में बहुत तेज भारीपन हो रहा है और बायां हाथ दुख रहा है। (Severe crushing chest pressure radiating to left arm)',
          'दर्द अचानक दो घंटे पहले शुरू हुआ और ठंडा पसीना आ रहा है। (Pain started suddenly 2 hours ago with diaphoresis)',
        ],
        sandhivata_joints: [
          'दोनों घुटनों में बहुत दर्द और सुबह उठने पर भारी जकड़न रहती है। (Severe knee pain with morning stiffness)',
          'सीढ़ियां चढ़ने में बहुत कट-कट की आवाज और दर्द होता है। (Crepitus and pain while climbing stairs)',
        ],
        amlapitta_digestion: [
          'छाती और गले में जलन होती है, खट्टी डकारें आती हैं। (Severe acid reflux and sour regurgitation)',
        ],
      };

      const pool = simulatedResponses[selectedComplaint.id] || simulatedResponses.chest_pain;
      const sample = pool[Math.floor(Math.random() * pool.length)];
      setSpokenTranscript(`"${sample}"`);
      setIsListening(false);
      handleSpokenVoiceInput(sample);
    }, 1800);
  };

  const handleSpokenVoiceInput = (text: string) => {
    // Red flag detection from voice
    const lower = text.toLowerCase();
    if (
      lower.includes('बायां हाथ') ||
      lower.includes('left arm') ||
      lower.includes('पसीना') ||
      lower.includes('crushing') ||
      lower.includes('cold sweat') ||
      lower.includes('घबराहट')
    ) {
      triggerRedFlagWarning(
        'Acute Coronary Syndrome (ACS / Angina Red-Flag)',
        'Spoken history describes crushing retrosternal pain radiating to left arm with cold diaphoresis.'
      );
    }
  };

  const triggerRedFlagWarning = (symptom: string, reason: string) => {
    const alert: RedFlagAlert = {
      id: `rf-${Date.now()}`,
      severity: 'CRITICAL_EMERGENCY',
      symptom,
      triggerReason: reason,
      actionRequired: 'Immediate priority triage to ECG room & emergency nursing desk.',
      timestamp: new Date().toLocaleTimeString(),
      acknowledged: false,
    };
    onRedFlagTriggered(alert);
    if (audioEnabled) {
      speakPrompt('चेतावनी: आपातकालीन लक्षण पाए गए हैं। नर्सिंग स्टाफ को सूचित किया जा रहा है।', 'hi');
    }
  };

  const handleSelectOption = (key: keyof SocratesHPI | 'specialAyush', value: string, isRedFlagTrigger?: boolean) => {
    if (isRedFlagTrigger) {
      triggerRedFlagWarning(
        `High-Risk Presentation: ${value}`,
        `Patient reported clinical criteria associated with immediate cardiovascular or respiratory risk.`
      );
    }

    if (key !== 'specialAyush') {
      setHpiState((prev) => {
        if (key === 'associations') {
          return {
            ...prev,
            associations: prev.associations.includes(value)
              ? prev.associations.filter((a) => a !== value)
              : [...prev.associations, value],
          };
        }
        return {
          ...prev,
          [key]: value,
        };
      });
    }

    // Auto advance to next question
    if (currentQuestionIndex < currentQuestions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    }
  };

  const handleFinishConversationalIntake = () => {
    stopSpeech();
    onComplete({
      chiefComplaint: selectedComplaint.nameEn,
      durationOfComplaint: '3 days (intermittent, worsening today)',
      hpi: hpiState,
      pastMedicalHistory,
      pastSurgicalHistory: ['No major surgeries reported'],
      drugAllergies: allergies,
      foodAllergies: ['None'],
      currentMedications: [],
      familyHistory: ['Father: Hypertensive & CAD', 'Mother: Type 2 Diabetes Mellitus'],
      personalHistory: {
        smoking: 'Never',
        alcohol: 'Never',
        diet: patient.opdTrack === 'ayush' ? 'Vegetarian with high spices' : 'Mixed diet',
        physicalActivity: 'Sedentary',
      },
      reviewOfSystems: [
        { system: 'Cardiovascular', symptoms: ['Chest heaviness', 'Palpitation'], isPositive: selectedComplaint.category === 'cardio' },
        { system: 'Musculoskeletal', symptoms: ['Janu sandhishoola', 'Morning stiffness'], isPositive: selectedComplaint.category === 'ayush_joint' },
        { system: 'Gastrointestinal', symptoms: ['Amlapitta', 'Irregular bowels'], isPositive: selectedComplaint.category === 'gastro' },
      ],
      ayushAssessment: patient.opdTrack === 'ayush' ? ayushPariksha : undefined,
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Kiosk Intake Sub-header & Progress */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-emerald-300 font-bold font-mono">
            02
          </div>
          <div>
            <h3 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
              <span>Step 2: Multimodal Conversational History Intake</span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono">
                Bhashini ASR + SOCRATES
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Patient: <strong className="text-slate-200">{patient.name}</strong> • Token:{' '}
              <span className="font-mono text-emerald-400">{patient.tokenNumber}</span>
            </p>
          </div>
        </div>

        {/* Sub-step indicator pills */}
        <div className="flex items-center gap-1.5 text-xs">
          <button
            type="button"
            onClick={() => setSubStep(1)}
            className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition-all ${
              subStep === 1 ? 'bg-emerald-600 text-white' : 'bg-slate-700/60 text-slate-400 hover:bg-slate-700'
            }`}
          >
            1. Chief Complaint
          </button>
          <button
            type="button"
            onClick={() => setSubStep(2)}
            className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition-all ${
              subStep === 2 ? 'bg-emerald-600 text-white' : 'bg-slate-700/60 text-slate-400 hover:bg-slate-700'
            }`}
          >
            2. SOCRATES Questions
          </button>
          {patient.opdTrack === 'ayush' && (
            <button
              type="button"
              onClick={() => setSubStep(3)}
              className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition-all ${
                subStep === 3 ? 'bg-amber-600 text-white' : 'bg-slate-700/60 text-slate-400 hover:bg-slate-700'
              }`}
            >
              3. दशविध परीक्षा (AYUSH)
            </button>
          )}
          <button
            type="button"
            onClick={() => setSubStep(4)}
            className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition-all ${
              subStep === 4 ? 'bg-emerald-600 text-white' : 'bg-slate-700/60 text-slate-400 hover:bg-slate-700'
            }`}
          >
            {patient.opdTrack === 'ayush' ? '4. Severity' : '3. Severity'}
          </button>
        </div>
      </div>

      {/* Voice Assistant Visualizer Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-700/80 rounded-2xl p-4 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            id="btn-voice-mic"
            type="button"
            onClick={toggleVoiceRecording}
            className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all cursor-pointer shadow-lg ${
              isListening
                ? 'bg-red-600 text-white animate-pulse ring-4 ring-red-500/40 shadow-red-900/50'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/60'
            }`}
            title="Tap to speak in Hindi or English"
          >
            {isListening ? <MicOff className="w-7 h-7" /> : <Mic className="w-7 h-7" />}
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-white text-sm">
                {isListening ? 'Bhashini ASR Listening...' : 'Dual-Mode Input: Tap or Speak'}
              </span>
              <span className="text-[10px] bg-slate-800 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30">
                AI4Bharat ASR
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 max-w-md">
              {isListening
                ? 'Speak naturally in your mother tongue. The AI will parse clinical entities.'
                : 'You can tap the large cards below or click the microphone to speak freely.'}
            </p>
          </div>
        </div>

        {spokenTranscript && (
          <div className="w-full sm:w-auto max-w-sm bg-slate-950/80 border border-slate-800 rounded-xl p-2.5 text-xs text-emerald-300 font-sans italic">
            <span className="text-slate-500 block text-[10px] uppercase font-bold not-italic">
              Captured Voice Entity:
            </span>
            {spokenTranscript}
          </div>
        )}
      </div>

      {/* SUB-STEP 1: CHIEF COMPLAINT SELECTION */}
      {subStep === 1 && (
        <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-lg font-bold text-white">
                What is your primary medical concern today? (मुख्य शिकायत क्या है?)
              </h4>
              <p className="text-xs text-slate-400 mt-1">
                Select your main symptom to launch the adaptive diagnostic tree.
              </p>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-lg bg-slate-700 text-slate-300">
              Touch to choose
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {CHIEF_COMPLAINTS.map((complaint) => {
              const isSelected = selectedComplaint.id === complaint.id;
              return (
                <button
                  key={complaint.id}
                  type="button"
                  onClick={() => setSelectedComplaint(complaint)}
                  className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex items-start justify-between gap-3 ${
                    isSelected
                      ? 'bg-emerald-950/80 border-emerald-500 ring-2 ring-emerald-500/50 shadow-md'
                      : 'bg-slate-900/70 border-slate-700/80 hover:border-slate-600 hover:bg-slate-850'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                          complaint.category === 'cardio'
                            ? 'bg-rose-500/20 text-rose-400'
                            : complaint.category === 'ayush_joint'
                            ? 'bg-amber-500/20 text-amber-400'
                            : 'bg-teal-500/20 text-teal-400'
                        }`}
                      >
                        {complaint.id === 'chest_pain' && <HeartPulse className="w-4 h-4" />}
                        {complaint.id === 'sandhivata_joints' && <Bone className="w-4 h-4" />}
                        {complaint.id === 'amlapitta_digestion' && <Flame className="w-4 h-4" />}
                        {complaint.id === 'breathlessness' && <Wind className="w-4 h-4" />}
                        {complaint.id === 'diabetes_hypertension' && <Activity className="w-4 h-4" />}
                      </div>
                      <span className="font-bold text-white text-sm">{complaint.nameEn}</span>
                    </div>
                    <p className="text-xs text-emerald-300/90 font-medium pl-10">{complaint.nameHi}</p>
                    {complaint.isRedFlagPotential && (
                      <span className="inline-block text-[10px] text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20 mt-1 ml-10">
                        ⚡ Priority Triage Monitored
                      </span>
                    )}
                  </div>
                  {isSelected && (
                    <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0 mt-1">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-700/80">
            <button
              type="button"
              onClick={onBackToProfile}
              className="px-5 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Identity</span>
            </button>
            <button
              type="button"
              onClick={() => setSubStep(2)}
              className="px-7 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-sm shadow-md flex items-center gap-2 cursor-pointer transition-all"
            >
              <span>Continue to Adaptive History</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* SUB-STEP 2: SOCRATES ADAPTIVE QUESTIONING */}
      {subStep === 2 && (
        <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-700/80 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-wider font-bold text-emerald-400">
                  Adaptive SOCRATES Clinical Branching
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-slate-700 text-slate-300 font-mono">
                  Q {currentQuestionIndex + 1} of {currentQuestions.length}
                </span>
              </div>
              <h4 className="text-base sm:text-lg font-bold text-white mt-1">
                {currentQuestions[currentQuestionIndex].questionEn}
              </h4>
              <p className="text-xs text-amber-300 font-medium">
                {currentQuestions[currentQuestionIndex].questionHi}
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                const q = currentQuestions[currentQuestionIndex];
                speakPrompt(currentLanguage === 'hi' ? q.questionHi : q.questionEn, currentLanguage);
              }}
              className="p-2.5 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-slate-200 cursor-pointer"
              title="Repeat question in voice"
            >
              <Volume2 className="w-5 h-5 text-emerald-400" />
            </button>
          </div>

          {/* Large touch options */}
          <div className="space-y-3">
            {currentQuestions[currentQuestionIndex].options.map((opt, idx) => {
              const key = currentQuestions[currentQuestionIndex].key;
              const isSelected =
                key === 'associations'
                  ? hpiState.associations.includes(opt.value)
                  : (hpiState as any)[key] === opt.value;

              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSelectOption(key, opt.value, opt.isRedFlagTrigger)}
                  className={`w-full p-4 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-emerald-950/90 border-emerald-500 shadow-md ring-2 ring-emerald-500/50'
                      : opt.isRedFlagTrigger
                      ? 'bg-slate-900/80 border-rose-900/60 hover:border-rose-600 hover:bg-rose-950/20'
                      : 'bg-slate-900/70 border-slate-700/80 hover:border-slate-600 hover:bg-slate-850'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white text-sm sm:text-base">{opt.labelEn}</span>
                      {opt.isRedFlagTrigger && (
                        <span className="text-[10px] px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 font-bold border border-rose-500/40">
                          Critical Trigger
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 font-sans">{opt.labelHi}</p>
                  </div>
                  <div
                    className={`w-6 h-6 rounded-full border flex items-center justify-center shrink-0 ${
                      isSelected ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-600 bg-slate-800'
                    }`}
                  >
                    {isSelected && <Check className="w-4 h-4" />}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-700/80">
            <button
              type="button"
              onClick={() => {
                if (currentQuestionIndex > 0) {
                  setCurrentQuestionIndex((prev) => prev - 1);
                } else {
                  setSubStep(1);
                }
              }}
              className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Previous Question</span>
            </button>

            {currentQuestionIndex < currentQuestions.length - 1 ? (
              <button
                type="button"
                onClick={() => setCurrentQuestionIndex((prev) => prev + 1)}
                className="px-6 py-2.5 bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer"
              >
                <span>Next Question</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  if (patient.opdTrack === 'ayush') {
                    setSubStep(3); // Dashavidha Pariksha
                  } else {
                    setSubStep(4); // Severity
                  }
                }}
                className="px-7 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-sm shadow-md flex items-center gap-2 cursor-pointer transition-all"
              >
                <span>Continue to Next Section</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* SUB-STEP 3: AYUSH DASHAVIDHA PARIKSHA (FOR AIIA AYURVEDA OPD) */}
      {subStep === 3 && patient.opdTrack === 'ayush' && (
        <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="border-b border-slate-700/80 pb-4">
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wider font-bold text-amber-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                अखिल भारतीय आयुर्वेद संस्थान (AIIA) • दशविध परीक्षा फ्रेमवर्क
              </span>
            </div>
            <h4 className="text-lg font-bold text-white mt-1">
              Dashavidha Pariksha (Ten-Fold Ayurvedic Clinical Assessment)
            </h4>
            <p className="text-xs text-slate-300 mt-0.5">
              Captures Prakriti, Vikriti, Agni (Digestive Fire), Koshtha (Bowel Habit), and Ahara-Vihara for personalized Ayurvedic management.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* 1. Prakriti (Constitution) */}
            <div className="bg-slate-900/80 border border-slate-700/80 rounded-xl p-4 space-y-2">
              <label className="block text-xs font-bold text-amber-300 uppercase tracking-wider">
                1. प्रकृति (Prakriti / Biological Constitution)
              </label>
              <select
                value={ayushPariksha.prakriti}
                onChange={(e) => setAyushPariksha({ ...ayushPariksha, prakriti: e.target.value as any })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
              >
                <option value="Vata">वातज (Vata Dominant - Dry skin, agile, erratic appetite)</option>
                <option value="Pitta">पित्तज (Pitta Dominant - Warm, sharp hunger, intolerant to heat)</option>
                <option value="Kapha">कफज (Kapha Dominant - Heavy build, steady, slow digestion)</option>
                <option value="Vata-Pitta">द्वन्द्वज: वात-पित्त (Vata-Pitta)</option>
                <option value="Vata-Kapha">द्वन्द्वज: वात-कफ (Vata-Kapha)</option>
                <option value="Pitta-Kapha">द्वन्द्वज: पित्त-कफ (Pitta-Kapha)</option>
                <option value="Tridoshaja">समदोष / त्रिदोषज (Tridoshaja)</option>
              </select>
            </div>

            {/* 2. Agni Pariksha */}
            <div className="bg-slate-900/80 border border-slate-700/80 rounded-xl p-4 space-y-2">
              <label className="block text-xs font-bold text-amber-300 uppercase tracking-wider">
                2. अग्नि परीक्षा (Digestive Capacity / Agni)
              </label>
              <select
                value={ayushPariksha.agni}
                onChange={(e) => setAyushPariksha({ ...ayushPariksha, agni: e.target.value as any })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
              >
                <option value="Vishama">विषमाग्नि (Vishama - Erratic, variable appetite & bloating)</option>
                <option value="Manda">मन्दाग्नि (Manda - Sluggish digestion, heaviness, low hunger)</option>
                <option value="Tikshna">तीक्ष्णाग्नि (Tikshna - Excessive sharp hunger, acidity/burning)</option>
                <option value="Sama">समाग्नि (Sama - Balanced, normal healthy digestion)</option>
              </select>
            </div>

            {/* 3. Koshtha Pariksha */}
            <div className="bg-slate-900/80 border border-slate-700/80 rounded-xl p-4 space-y-2">
              <label className="block text-xs font-bold text-amber-300 uppercase tracking-wider">
                3. कोष्ठ परीक्षा (Bowel Habit / Koshtha)
              </label>
              <select
                value={ayushPariksha.koshtha}
                onChange={(e) => setAyushPariksha({ ...ayushPariksha, koshtha: e.target.value as any })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
              >
                <option value="Krura">क्रूर कोष्ठ (Krura - Hard dry stools, chronic constipation, Vata)</option>
                <option value="Madhyama">मध्यम कोष्ठ (Madhyama - Regular soft formed stool daily)</option>
                <option value="Mridu">मृदु कोष्ठ (Mridu - Loose stools easily with warm milk, Pitta)</option>
              </select>
            </div>

            {/* 4. Sattva (Mental resilience) */}
            <div className="bg-slate-900/80 border border-slate-700/80 rounded-xl p-4 space-y-2">
              <label className="block text-xs font-bold text-amber-300 uppercase tracking-wider">
                4. सत्त्व एवं व्यायाम शक्ति (Psychic & Work Capacity)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-[11px] text-slate-400 block mb-1">सत्त्व (Sattva):</span>
                  <select
                    value={ayushPariksha.sattva}
                    onChange={(e) => setAyushPariksha({ ...ayushPariksha, sattva: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white"
                  >
                    <option value="Pravara">प्रवर (High)</option>
                    <option value="Madhyama">मध्यम (Medium)</option>
                    <option value="Avara">अवर (Low)</option>
                  </select>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block mb-1">व्यायाम (Vyayama):</span>
                  <select
                    value={ayushPariksha.vyayamaShakti}
                    onChange={(e) => setAyushPariksha({ ...ayushPariksha, vyayamaShakti: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white"
                  >
                    <option value="Uttama">उत्तम (High)</option>
                    <option value="Madhyama">मध्यम (Medium)</option>
                    <option value="Hina">हीन (Low/Fatigued)</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* 5. Ahara-Vihara assessment */}
          <div className="bg-slate-900/80 border border-slate-700/80 rounded-xl p-4 space-y-3">
            <label className="block text-xs font-bold text-amber-300 uppercase tracking-wider">
              5. आहार-विहार मूल्यांकन (Dietary & Lifestyle Patterns)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <span className="text-[11px] text-slate-400 block mb-1">खान-पान प्रकार (Diet Habit):</span>
                <select
                  value={ayushPariksha.aharaVihara.dietType}
                  onChange={(e) =>
                    setAyushPariksha({
                      ...ayushPariksha,
                      aharaVihara: { ...ayushPariksha.aharaVihara, dietType: e.target.value as any },
                    })
                  }
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="Shakahari (Veg)">शाकाहारी (Vegetarian)</option>
                  <option value="Mishrahari (Non-Veg)">मिश्राहारी (Mixed / Non-Vegetarian)</option>
                  <option value="Alpahari">अल्पाहारी (Irregular / Low Calorie)</option>
                </select>
              </div>

              <div>
                <span className="text-[11px] text-slate-400 block mb-1">निद्रा पैटर्न (Sleep Quality):</span>
                <select
                  value={ayushPariksha.aharaVihara.sleepPattern}
                  onChange={(e) =>
                    setAyushPariksha({
                      ...ayushPariksha,
                      aharaVihara: { ...ayushPariksha.aharaVihara, sleepPattern: e.target.value as any },
                    })
                  }
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="Samyak (Normal)">सम्यक् निद्रा (Sound 6-8 hrs sleep)</option>
                  <option value="Anidra (Insomnia)">अनिद्रा / खंडित निद्रा (Disturbed / Insomnia)</option>
                  <option value="Atinidra (Excessive)">अतिनिद्रा / आलस्य (Excessive sleep / lethargy)</option>
                </select>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-700/80">
            <button
              type="button"
              onClick={() => setSubStep(2)}
              className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Questions</span>
            </button>
            <button
              type="button"
              onClick={() => setSubStep(4)}
              className="px-7 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-sm shadow-md flex items-center gap-2 cursor-pointer transition-all"
            >
              <span>Continue to Severity & Review</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* SUB-STEP 4: SEVERITY SLIDER & REVIEW */}
      {subStep === 4 && (
        <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="border-b border-slate-700/80 pb-4">
            <h4 className="text-lg font-bold text-white">
              Symptom Severity & Discomfort Rating (दर्द या तकलीफ की तीव्रता)
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              Move the slider or tap the visual facial rating scale from 1 (mild) to 10 (unbearable).
            </p>
          </div>

          {/* Severity Visual Scale */}
          <div className="bg-slate-900/80 border border-slate-700 rounded-2xl p-6 text-center space-y-4">
            <div className="flex items-center justify-center gap-3">
              {hpiState.severity <= 3 ? (
                <Smile className="w-12 h-12 text-emerald-400" />
              ) : hpiState.severity <= 7 ? (
                <Meh className="w-12 h-12 text-amber-400" />
              ) : (
                <Frown className="w-12 h-12 text-rose-500 animate-pulse" />
              )}
              <div className="text-left">
                <span className="text-3xl font-extrabold text-white font-mono">{hpiState.severity} / 10</span>
                <span className="block text-xs font-semibold text-slate-400">
                  {hpiState.severity <= 3
                    ? 'Mild / Bearable Discomfort'
                    : hpiState.severity <= 7
                    ? 'Moderate to Severe Pain'
                    : 'Critical / Intolerable Distress'}
                </span>
              </div>
            </div>

            <div className="max-w-md mx-auto px-4">
              <input
                id="input-severity-range"
                type="range"
                min="1"
                max="10"
                value={hpiState.severity}
                onChange={(e) => setHpiState({ ...hpiState, severity: Number(e.target.value) })}
                className="w-full accent-emerald-500 cursor-pointer h-2 bg-slate-700 rounded-lg"
              />
              <div className="flex justify-between text-[11px] font-mono text-slate-500 mt-1">
                <span>1 (Mild)</span>
                <span>5 (Moderate)</span>
                <span className="text-rose-400">10 (Extreme)</span>
              </div>
            </div>
          </div>

          {/* Past History & Allergies Quick Check */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-900/70 border border-slate-700/80 rounded-xl p-4">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
                Existing Medical Conditions (पूर्व बीमारियां)
              </span>
              <div className="space-y-1.5">
                {['Diabetes Mellitus', 'Hypertension', 'Thyroid Disorder', 'Asthma / Bronchitis'].map(
                  (cond) => {
                    const isChecked = pastMedicalHistory.some((m) => m.toLowerCase().includes(cond.toLowerCase().split(' ')[0]));
                    return (
                      <label key={cond} className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setPastMedicalHistory([...pastMedicalHistory, cond]);
                            } else {
                              setPastMedicalHistory(pastMedicalHistory.filter((m) => !m.includes(cond)));
                            }
                          }}
                          className="rounded accent-emerald-500"
                        />
                        <span>{cond}</span>
                      </label>
                    );
                  }
                )}
              </div>
            </div>

            <div className="bg-slate-900/70 border border-slate-700/80 rounded-xl p-4">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
                Drug Allergies (दवाइयों से एलर्जी)
              </span>
              <div className="space-y-1.5">
                {['Penicillin / Amoxicillin', 'Sulfa Drugs', 'Paracetamol / NSAIDs', 'None / NKDA'].map(
                  (item) => (
                    <label key={item} className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={allergies.includes(item)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setAllergies([...allergies, item]);
                          } else {
                            setAllergies(allergies.filter((a) => a !== item));
                          }
                        }}
                        className="rounded accent-emerald-500"
                      />
                      <span>{item}</span>
                    </label>
                  )
                )}
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-700/80">
            <button
              type="button"
              onClick={() => {
                if (patient.opdTrack === 'ayush') {
                  setSubStep(3);
                } else {
                  setSubStep(2);
                }
              }}
              className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            <button
              id="btn-proceed-to-scan"
              type="button"
              onClick={handleFinishConversationalIntake}
              className="px-8 py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-lg flex items-center gap-2 cursor-pointer transition-all"
            >
              <span>Proceed to Document Digitization (Step 3)</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
