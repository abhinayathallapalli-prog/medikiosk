import React, { useState } from 'react';
import { 
  Building2, 
  Languages, 
  Volume2, 
  VolumeX, 
  Stethoscope, 
  MonitorSmartphone, 
  Download, 
  ShieldCheck, 
  AlertCircle,
  Sparkles,
  Loader2
} from 'lucide-react';
import { LanguageCode } from '../types';
import { SUPPORTED_LANGUAGES, UI_TEXTS } from '../data/translations';
import { generateProjectZip, triggerDownload } from '../utils/zipExporter';

interface HeaderProps {
  currentLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  activeView: 'kiosk' | 'doctor';
  onViewChange: (view: 'kiosk' | 'doctor') => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  activeToken?: string;
  hasRedFlag?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentLanguage,
  onLanguageChange,
  activeView,
  onViewChange,
  audioEnabled,
  onToggleAudio,
  activeToken,
  hasRedFlag = false,
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const t = UI_TEXTS[currentLanguage] || UI_TEXTS.en;

  const handleDownloadZip = async () => {
    try {
      setIsExporting(true);
      const blob = await generateProjectZip();
      triggerDownload(blob, 'MediKiosk-AI-Clinical-History-Platform.zip');
    } catch (err) {
      console.error('Failed to export zip:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 shadow-lg">
      {/* Top Ministry Bar */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-amber-950 px-4 py-1.5 text-xs text-slate-300 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="font-semibold text-emerald-400">आयुष मंत्रालय | Ministry of Ayush</span>
          <span className="text-slate-500">•</span>
          <span>अखिल भारतीय आयुर्वेद संस्थान (AIIA) New Delhi</span>
          <span className="text-slate-500">•</span>
          <span className="text-amber-400 font-medium">ABDM & DPDP Act 2023 Compliant</span>
        </div>
        <div className="hidden sm:flex items-center gap-3">
          <span className="flex items-center gap-1 text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>FHIR R4 Interoperable</span>
          </span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-400">OPD Queue Throughput Booster</span>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Brand identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-white shadow-md shadow-emerald-900/40 border border-emerald-400/30">
            <Building2 className="w-5 h-5 text-emerald-100" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-white tracking-tight flex items-center gap-1.5">
                <span>MediKiosk</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono">
                  AI-OPD
                </span>
              </h1>
              {hasRedFlag && (
                <span className="animate-bounce flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-red-600 text-white font-bold shadow-md shadow-red-900/50">
                  <AlertCircle className="w-3 h-3" />
                  TRIAGE RED-FLAG
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400">
              Multimodal Clinical Intake • AIIA Dashavidha Pariksha • Bhashini Voice
            </p>
          </div>
        </div>

        {/* Center/Right Controls */}
        <div className="flex items-center flex-wrap gap-2 sm:gap-3">
          {/* Active View Switcher */}
          <div className="bg-slate-800/90 p-1 rounded-xl border border-slate-700/80 flex items-center gap-1 shadow-inner">
            <button
              id="btn-view-kiosk"
              type="button"
              onClick={() => onViewChange('kiosk')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeView === 'kiosk'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/60'
              }`}
            >
              <MonitorSmartphone className="w-3.5 h-3.5" />
              <span>{t.patientKioskView || 'Patient Kiosk'}</span>
            </button>
            <button
              id="btn-view-doctor"
              type="button"
              onClick={() => onViewChange('doctor')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeView === 'doctor'
                  ? 'bg-teal-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/60'
              }`}
            >
              <Stethoscope className="w-3.5 h-3.5" />
              <span>{t.doctorView || 'Doctor EMR Desk'}</span>
            </button>
          </div>

          {/* Language Selector */}
          <div className="relative flex items-center bg-slate-800/80 border border-slate-700 rounded-xl px-2.5 py-1.5">
            <Languages className="w-4 h-4 text-emerald-400 mr-2 shrink-0" />
            <select
              id="select-language"
              value={currentLanguage}
              aria-label="Select preferred language"
              onChange={(e) => onLanguageChange(e.target.value as LanguageCode)}
              className="bg-transparent text-xs font-medium text-slate-200 outline-none cursor-pointer pr-1"
            >
              {SUPPORTED_LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code} className="bg-slate-900 text-slate-100">
                  {lang.nativeLabel} ({lang.label})
                </option>
              ))}
            </select>
          </div>

          {/* Audio speech toggle */}
          <button
            id="btn-toggle-audio"
            type="button"
            onClick={onToggleAudio}
            title={audioEnabled ? 'Voice Guidance Active' : 'Voice Guidance Muted'}
            className={`p-2 rounded-xl border text-xs flex items-center gap-1 transition-all ${
              audioEnabled
                ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 hover:bg-emerald-500/30'
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            {audioEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden md:inline text-[11px] font-medium">
              {audioEnabled ? 'Bhashini TTS On' : 'TTS Muted'}
            </span>
          </button>

          {/* Download Zip button */}
          <button
            id="btn-export-zip"
            type="button"
            onClick={handleDownloadZip}
            disabled={isExporting}
            className="px-3 py-1.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-amber-900/30 border border-amber-500/30 transition-all cursor-pointer"
            title="Download complete source code in a ZIP file"
          >
            {isExporting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Zipping...</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>Download ZIP</span>
              </>
            )}
          </button>

          {/* Active Token Badge */}
          {activeToken && (
            <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 bg-emerald-950/80 border border-emerald-600/40 rounded-xl text-xs text-emerald-300">
              <span className="text-slate-400">Token:</span>
              <span className="font-mono font-bold text-emerald-200">{activeToken}</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
