import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  FileText, 
  Volume2, 
  ArrowRight, 
  Printer, 
  Share2, 
  ShieldCheck, 
  Stethoscope, 
  Sparkles,
  Code,
  Building2,
  Calendar,
  Clock,
  UserCheck,
  AlertCircle
} from 'lucide-react';
import { PatientProfile, ClinicalHistoryRecord, LanguageCode } from '../types';
import { UI_TEXTS } from '../data/translations';
import { generateFhirR4Bundle } from '../utils/fhirGenerator';
import { speakPrompt } from '../utils/speechHelper';

interface SummaryRoutingProps {
  patient: PatientProfile;
  record: ClinicalHistoryRecord;
  currentLanguage: LanguageCode;
  audioEnabled: boolean;
  onGoToDoctorDesk: () => void;
  onResetForNewPatient: () => void;
}

export const SummaryRouting: React.FC<SummaryRoutingProps> = ({
  patient,
  record,
  currentLanguage,
  audioEnabled,
  onGoToDoctorDesk,
  onResetForNewPatient,
}) => {
  const t = UI_TEXTS[currentLanguage] || UI_TEXTS.en;
  const [showFhirJson, setShowFhirJson] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const fhirBundle = generateFhirR4Bundle(patient, record);

  // Play audio confirmation on mount
  useEffect(() => {
    if (audioEnabled) {
      const confirmationSpeech = currentLanguage === 'hi'
        ? `आपका क्लिनिकल इतिहास तैयार हो चुका है। टोकन संख्या ${patient.tokenNumber}। कृपया कमरा नंबर 14 में डॉक्टर के पास जाएं।`
        : `Your clinical intake summary has been created. Token number is ${patient.tokenNumber}. Please proceed to room number 14 for consultation.`;
      speakPrompt(confirmationSpeech, currentLanguage);
    }
  }, [audioEnabled, currentLanguage, patient.tokenNumber]);

  const handleCopyFhir = () => {
    navigator.clipboard.writeText(JSON.stringify(fhirBundle, null, 2));
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Success Token Banner */}
      <div className="bg-gradient-to-br from-emerald-900/90 via-slate-900 to-teal-950 border border-emerald-500/50 rounded-2xl p-6 shadow-2xl relative overflow-hidden text-center sm:text-left">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold border border-emerald-500/40">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{t.summaryReady || 'Structured Clinical History Generated'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Pushed to Hospital Information System (HIS)
            </h2>
            <p className="text-sm text-slate-300 max-w-xl">
              Linked to ABHA Profile <span className="font-mono text-emerald-300">{patient.abhaId}</span>. The physician will see this structured record the instant your token is called.
            </p>
          </div>

          {/* OPD Token Box */}
          <div className="bg-slate-950/90 border-2 border-emerald-500/80 rounded-2xl p-4 text-center shrink-0 w-full sm:w-48 shadow-xl">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              OPD Queue Token
            </span>
            <span className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono my-1 block">
              {patient.tokenNumber}
            </span>
            <span className="text-xs font-bold text-amber-300 block">Room No. 14</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">{patient.department}</span>
          </div>
        </div>
      </div>

      {/* Structured Summary Preview (Draft for Consultation Room) */}
      <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-6 shadow-xl space-y-5">
        <div className="flex flex-wrap items-center justify-between border-b border-slate-700/80 pb-4 gap-2">
          <div>
            <h3 className="font-bold text-white text-base sm:text-lg flex items-center gap-2">
              <FileText className="w-5 h-5 text-emerald-400" />
              <span>Physician-Ready Clinical Summary (Draft)</span>
            </h3>
            <p className="text-xs text-slate-400">
              Generated in standard clinical intake format (Complies with ABDM FHIR R4 profile)
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowFhirJson(!showFhirJson)}
              className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Code className="w-3.5 h-3.5 text-emerald-400" />
              <span>{showFhirJson ? 'Hide FHIR Bundle' : 'Inspect ABDM FHIR JSON'}</span>
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Slip</span>
            </button>
          </div>
        </div>

        {/* FHIR JSON Drawer if active */}
        {showFhirJson && (
          <div className="bg-slate-950 border border-slate-700 rounded-xl p-4 text-xs font-mono space-y-2">
            <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2">
              <span className="text-emerald-400 font-bold">FHIR R4 Composition & Bundle (ABDM Standard)</span>
              <button
                type="button"
                onClick={handleCopyFhir}
                className="text-xs text-slate-300 hover:text-white bg-slate-800 px-2 py-1 rounded cursor-pointer"
              >
                {isCopied ? 'Copied to Clipboard!' : 'Copy JSON'}
              </button>
            </div>
            <pre className="text-slate-300 overflow-x-auto max-h-72 p-2 bg-slate-900 rounded">
              {JSON.stringify(fhirBundle, null, 2)}
            </pre>
          </div>
        )}

        {/* Structured Sections */}
        <div className="space-y-4">
          {/* Section 1: Chief Complaint & SOCRATES */}
          <div className="bg-slate-900/80 border border-slate-700/80 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                1. Chief Complaint & History of Present Illness (HPI)
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                Pain Severity: {record.hpi.severity}/10
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-200">
              <div>
                <span className="text-slate-400 block">Presenting Complaint:</span>
                <strong className="text-white text-sm">{record.chiefComplaint}</strong> ({record.durationOfComplaint})
              </div>
              <div>
                <span className="text-slate-400 block">Site & Radiation:</span>
                <span>{record.hpi.site} • {record.hpi.radiation}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Onset & Character:</span>
                <span>{record.hpi.onset} • {record.hpi.character}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Associated Symptoms:</span>
                <span>{record.hpi.associations.join(', ') || 'None reported'}</span>
              </div>
            </div>
          </div>

          {/* Section 2: AYUSH Dashavidha Pariksha (if applicable) */}
          {record.ayushAssessment && (
            <div className="bg-amber-950/30 border border-amber-500/40 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  2. Dashavidha Pariksha (दशविध परीक्षा मूल्यांकन)
                </span>
                <span className="text-[11px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-semibold">
                  AIIA Ayurveda Protocol
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-slate-200">
                <div className="bg-slate-950/60 p-2 rounded-lg border border-amber-900/40">
                  <span className="text-[10px] text-slate-400 block">प्रकृति (Prakriti):</span>
                  <strong className="text-amber-300">{record.ayushAssessment.prakriti}</strong>
                </div>
                <div className="bg-slate-950/60 p-2 rounded-lg border border-amber-900/40">
                  <span className="text-[10px] text-slate-400 block">अग्नि (Agni):</span>
                  <strong className="text-amber-300">{record.ayushAssessment.agni}</strong>
                </div>
                <div className="bg-slate-950/60 p-2 rounded-lg border border-amber-900/40">
                  <span className="text-[10px] text-slate-400 block">कोष्ठ (Koshtha):</span>
                  <strong className="text-amber-300">{record.ayushAssessment.koshtha}</strong>
                </div>
                <div className="bg-slate-950/60 p-2 rounded-lg border border-amber-900/40">
                  <span className="text-[10px] text-slate-400 block">सत्त्व / व्यायाम:</span>
                  <strong className="text-amber-300">{record.ayushAssessment.sattva} / {record.ayushAssessment.vyayamaShakti}</strong>
                </div>
              </div>
              <p className="text-[11px] text-slate-300 italic pt-1">
                Vikriti Imbalance: {record.ayushAssessment.vikriti}. Diet: {record.ayushAssessment.aharaVihara.dietType}, Sleep: {record.ayushAssessment.aharaVihara.sleepPattern}.
              </p>
            </div>
          )}

          {/* Section 3: Reconciled Prior Medications & Abnormal Labs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-900/80 border border-slate-700/80 rounded-xl p-3.5 space-y-2">
              <span className="text-xs font-bold text-teal-400 uppercase tracking-wider block">
                3. Current Active Medications ({record.currentMedications.length})
              </span>
              {record.currentMedications.length > 0 ? (
                <ul className="space-y-1 text-xs text-slate-200">
                  {record.currentMedications.map((m, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-teal-400">•</span>
                      <span>
                        <strong>{m.name}</strong> {m.dosage} ({m.frequency})
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-xs text-slate-400 italic">Extracted from prior digitized prescriptions.</p>
              )}
            </div>

            <div className="bg-slate-900/80 border border-slate-700/80 rounded-xl p-3.5 space-y-2">
              <span className="text-xs font-bold text-rose-400 uppercase tracking-wider block">
                4. Key Investigation Alerts
              </span>
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-rose-300 bg-rose-950/30 p-1.5 rounded">
                  <span>HbA1c Glycated Hemoglobin:</span>
                  <strong className="font-mono">9.2 % (High)</strong>
                </div>
                <div className="flex items-center justify-between text-amber-300 bg-amber-950/30 p-1.5 rounded">
                  <span>Serum Creatinine:</span>
                  <strong className="font-mono">1.28 mg/dL (Elevated)</strong>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Gateway to Doctor Consultation Room (Step 5) */}
        <div className="flex flex-col sm:flex-row items-center justify-between pt-4 border-t border-slate-700/80 gap-3">
          <button
            type="button"
            onClick={onResetForNewPatient}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-700 text-xs font-semibold cursor-pointer"
          >
            Start New Patient Intake
          </button>

          <button
            id="btn-enter-doctor-desk"
            type="button"
            onClick={onGoToDoctorDesk}
            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-extrabold rounded-xl shadow-xl shadow-emerald-950/80 flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Stethoscope className="w-5 h-5" />
            <span>Open Physician Consultation Screen (Step 5)</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
