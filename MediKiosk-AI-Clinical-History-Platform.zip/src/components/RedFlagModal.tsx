import React from 'react';
import { AlertTriangle, Siren, PhoneCall, ArrowRight, X, ShieldAlert } from 'lucide-react';
import { RedFlagAlert } from '../types';

interface RedFlagModalProps {
  alert: RedFlagAlert | null;
  onClose: () => void;
  onDispatchEmergency: () => void;
}

export const RedFlagModal: React.FC<RedFlagModalProps> = ({
  alert,
  onClose,
  onDispatchEmergency,
}) => {
  if (!alert) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border-2 border-red-500 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl shadow-red-950/80 space-y-6 relative overflow-hidden">
        {/* Flashing Top Border */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-red-600 via-amber-500 to-red-600 animate-pulse"></div>

        <div className="flex items-start justify-between gap-4">
          <div className="w-14 h-14 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-red-500 shrink-0">
            <Siren className="w-8 h-8 animate-bounce" />
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600 text-white text-xs font-bold uppercase tracking-wider">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Emergency Red-Flag Triggered</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            {alert.symptom}
          </h3>
          <p className="text-xs sm:text-sm text-red-200 leading-relaxed">
            {alert.triggerReason}
          </p>
        </div>

        <div className="bg-red-950/40 border border-red-500/40 rounded-2xl p-4 text-xs text-red-200 space-y-1">
          <strong className="text-white block font-semibold">Triage Protocol Action Required:</strong>
          <p>{alert.actionRequired}</p>
          <span className="text-[10px] text-red-300/80 block pt-1">
            Timestamp: {alert.timestamp} • Emergency Desk Notified Automatically
          </span>
        </div>

        <div className="space-y-2.5 pt-2">
          <button
            type="button"
            onClick={onDispatchEmergency}
            className="w-full py-3.5 bg-red-600 hover:bg-red-500 text-white font-extrabold rounded-xl shadow-lg shadow-red-950/60 flex items-center justify-center gap-2 cursor-pointer transition-all text-sm"
          >
            <PhoneCall className="w-4 h-4" />
            <span>Dispatch to Emergency Triage & ECG Room</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl cursor-pointer"
          >
            Acknowledge & Continue History Intake
          </button>
        </div>
      </div>
    </div>
  );
};
