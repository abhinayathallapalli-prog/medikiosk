import React, { useState } from 'react';
import { 
  FileText, 
  Upload, 
  Camera, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Calendar, 
  Pill, 
  Activity, 
  ArrowRight, 
  ArrowLeft, 
  Trash2, 
  Eye, 
  Sparkles,
  ShieldCheck,
  Plus,
  Loader2,
  FileCheck
} from 'lucide-react';
import { MedicalDocument, LanguageCode, ExtractedMedication, ExtractedLabResult } from '../types';
import { INITIAL_SAMPLE_DOCUMENTS } from '../data/clinicalKnowledge';
import { UI_TEXTS } from '../data/translations';

interface DocumentScannerProps {
  documents: MedicalDocument[];
  onUpdateDocuments: (docs: MedicalDocument[]) => void;
  currentLanguage: LanguageCode;
  onProceed: () => void;
  onBack: () => void;
}

export const DocumentScanner: React.FC<DocumentScannerProps> = ({
  documents,
  onUpdateDocuments,
  currentLanguage,
  onProceed,
  onBack,
}) => {
  const t = UI_TEXTS[currentLanguage] || UI_TEXTS.en;

  const [activeTab, setActiveTab] = useState<'timeline' | 'medications' | 'labs'>('timeline');
  const [selectedDoc, setSelectedDoc] = useState<MedicalDocument | null>(documents[1] || documents[0] || null);
  const [isScanningNew, setIsScanningNew] = useState(false);
  const [uploadError, setUploadError] = useState('');

  // Handle mock file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    simulateOcrPipeline(file.name, 'Prescription');
  };

  const handleCameraCaptureSimulation = () => {
    simulateOcrPipeline(`Kiosk_Camera_Scan_${Date.now().toString().slice(-4)}.jpg`, 'Lab Report');
  };

  const simulateOcrPipeline = (fileName: string, type: 'Prescription' | 'Lab Report') => {
    setIsScanningNew(true);
    setUploadError('');

    setTimeout(() => {
      const newDoc: MedicalDocument = {
        id: `doc-${Date.now()}`,
        name: fileName,
        documentType: type,
        date: new Date().toISOString().split('T')[0],
        hospitalName: 'AIIMS / AIIA Outpatient Record',
        fileSize: '1.2 MB',
        ocrStatus: 'completed',
        extractedText: 'OCR Result: Patient scanned prescription. Extracted active medications: Tab Pantoprazole 40mg OD, Tab Calcium + Vit D3 OD. Normal CBC report.',
        extractedDiagnoses: ['GERD / Amlapitta', 'Nutritional Osteopenia'],
        extractedMedications: [
          {
            name: 'Pantoprazole',
            dosage: '40 mg',
            frequency: 'Once daily before breakfast',
            duration: '14 days',
            prescribedBy: 'OPD Duty Medical Officer',
          },
          {
            name: 'Calcium Carbonate + Vit D3',
            dosage: '500 mg',
            frequency: 'Once daily after dinner',
            duration: '30 days',
            prescribedBy: 'OPD Duty Medical Officer',
          },
        ],
        extractedLabResults: [
          {
            testName: 'Hemoglobin (Hb)',
            resultValue: '12.8',
            unit: 'g/dL',
            referenceRange: '12.0 - 15.5 g/dL',
            isAbnormal: false,
          },
          {
            testName: 'Serum Uric Acid',
            resultValue: '7.4',
            unit: 'mg/dL',
            referenceRange: '3.5 - 7.2 mg/dL',
            isAbnormal: true,
            flagType: 'HIGH',
          },
        ],
        notes: 'Multilingual OCR accurately extracted tabular test parameters and bilingual medicine names.',
        abnormalWarnings: ['Serum Uric Acid is elevated at 7.4 mg/dL. Correlation with Sandhivata joint symptoms advised.'],
      };

      const updated = [newDoc, ...documents];
      onUpdateDocuments(updated);
      setSelectedDoc(newDoc);
      setIsScanningNew(false);
    }, 1500);
  };

  const handleDeleteDoc = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = documents.filter((d) => d.id !== id);
    onUpdateDocuments(updated);
    if (selectedDoc?.id === id) {
      setSelectedDoc(updated[0] || null);
    }
  };

  // Collect all extracted medications across all digitized documents
  const allMedications: ExtractedMedication[] = documents.flatMap((d) => d.extractedMedications);

  // Collect all extracted lab results across all digitized documents
  const allLabResults: ExtractedLabResult[] = documents.flatMap((d) => d.extractedLabResults);

  // Collect all abnormal warnings
  const allWarnings: string[] = documents.flatMap((d) => d.abnormalWarnings);

  // Sort documents chronologically (newest first)
  const sortedDocs = [...documents].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-950 border border-teal-500/40 flex items-center justify-center text-teal-300 font-bold font-mono">
            03
          </div>
          <div>
            <h3 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
              <span>Step 3: Medical Document Digitization & OCR Intelligence</span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-400 font-mono">
                Multilingual OCR Engine
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Digitize handwritten/printed paper prescriptions, lab reports, and discharge summaries.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCameraCaptureSimulation}
            disabled={isScanningNew}
            className="px-3.5 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow transition-all"
          >
            <Camera className="w-4 h-4 text-teal-400" />
            <span>Kiosk Camera Scan</span>
          </button>

          <label className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow transition-all">
            <Upload className="w-4 h-4" />
            <span>Upload Document</span>
            <input
              type="file"
              accept=".pdf,.png,.jpg,.jpeg"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* Scanning Loader Overlay */}
      {isScanningNew && (
        <div className="bg-teal-950/70 border border-teal-500/60 rounded-2xl p-6 text-center space-y-3 animate-pulse shadow-xl">
          <Loader2 className="w-8 h-8 text-teal-400 animate-spin mx-auto" />
          <h4 className="font-bold text-white text-base">Running AI Medical OCR Pipeline...</h4>
          <p className="text-xs text-teal-200">
            Scanning bilingual printed & handwritten text • Extracting ICD diagnoses • Titrating lab reference ranges
          </p>
        </div>
      )}

      {/* Main Document Layout: Left Document Timeline, Right Extraction Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Digitized Documents List & Timeline */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center justify-between mb-3 border-b border-slate-700/80 pb-2">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-teal-400" />
                Chronological Medical Timeline ({sortedDocs.length})
              </span>
              <span className="text-[11px] text-teal-400 font-mono">Auto-Dated</span>
            </div>

            <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
              {sortedDocs.map((doc) => {
                const isSelected = selectedDoc?.id === doc.id;
                return (
                  <div
                    key={doc.id}
                    onClick={() => setSelectedDoc(doc)}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-teal-950/80 border-teal-500 ring-1 ring-teal-500/60 shadow-md'
                        : 'bg-slate-900/80 border-slate-700/80 hover:border-slate-600 hover:bg-slate-850'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-teal-300 font-medium">
                            {doc.documentType}
                          </span>
                          <span className="text-[11px] text-slate-400 flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {doc.date}
                          </span>
                        </div>
                        <h5 className="font-semibold text-white text-xs sm:text-sm mt-1">{doc.name}</h5>
                        <p className="text-[11px] text-slate-400">{doc.hospitalName}</p>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => handleDeleteDoc(doc.id, e)}
                        className="text-slate-500 hover:text-rose-400 p-1 rounded hover:bg-slate-800 cursor-pointer"
                        title="Remove Document"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Quick Pill summaries */}
                    <div className="flex flex-wrap gap-1.5 mt-2 pt-2 border-t border-slate-800">
                      {doc.extractedDiagnoses.map((diag, idx) => (
                        <span key={idx} className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">
                          {diag}
                        </span>
                      ))}
                      {doc.extractedLabResults.filter((l) => l.isAbnormal).length > 0 && (
                        <span className="text-[10px] bg-rose-500/20 text-rose-300 px-1.5 py-0.5 rounded font-bold">
                          ⚠️ {doc.extractedLabResults.filter((l) => l.isAbnormal).length} Out of Range
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Deep Extracted Intelligence */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-5 shadow-xl space-y-4">
            {/* View Selector Tabs */}
            <div className="flex items-center justify-between border-b border-slate-700/80 pb-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('timeline')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                    activeTab === 'timeline' ? 'bg-teal-600 text-white' : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Document Details & Text
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('medications')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1 ${
                    activeTab === 'medications' ? 'bg-teal-600 text-white' : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <Pill className="w-3.5 h-3.5" />
                  <span>All Extracted Meds ({allMedications.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('labs')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1 ${
                    activeTab === 'labs' ? 'bg-teal-600 text-white' : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>Lab Investigations ({allLabResults.length})</span>
                </button>
              </div>

              <span className="text-[11px] text-emerald-400 font-mono hidden sm:inline">
                OCR Accuracy: 98.4%
              </span>
            </div>

            {/* TAB 1: CURRENT SELECTED DOCUMENT DETAILS */}
            {activeTab === 'timeline' && selectedDoc && (
              <div className="space-y-3">
                <div className="bg-slate-900/80 border border-slate-700/80 rounded-xl p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-sm">{selectedDoc.name}</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold">
                      OCR Extracted
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 font-mono bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                    {selectedDoc.extractedText}
                  </p>
                  <div className="text-[11px] text-slate-400 italic">
                    {selectedDoc.notes}
                  </div>
                </div>

                {/* Abnormal Warnings Box */}
                {selectedDoc.abnormalWarnings.length > 0 && (
                  <div className="bg-amber-950/40 border border-amber-500/40 rounded-xl p-3.5 space-y-1.5">
                    <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4" />
                      Clinical Warning & Drug-Safety Flag
                    </span>
                    {selectedDoc.abnormalWarnings.map((warn, i) => (
                      <p key={i} className="text-xs text-amber-200 leading-relaxed">
                        • {warn}
                      </p>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: EXTRACTED ACTIVE MEDICATIONS (CHRONOLOGICAL) */}
            {activeTab === 'medications' && (
              <div className="space-y-3">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-700 text-slate-400 uppercase font-semibold">
                        <th className="py-2 px-2">Medication Name</th>
                        <th className="py-2 px-2">Dosage</th>
                        <th className="py-2 px-2">Frequency</th>
                        <th className="py-2 px-2">Duration</th>
                        <th className="py-2 px-2">Source</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {allMedications.map((med, idx) => (
                        <tr key={idx} className="hover:bg-slate-900/60 text-slate-200">
                          <td className="py-2 px-2 font-semibold text-white flex items-center gap-1.5">
                            <Pill className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                            <span>{med.name}</span>
                          </td>
                          <td className="py-2 px-2 font-mono text-emerald-300">{med.dosage}</td>
                          <td className="py-2 px-2">{med.frequency}</td>
                          <td className="py-2 px-2 text-slate-400">{med.duration}</td>
                          <td className="py-2 px-2 text-[10px] text-slate-500">{med.prescribedBy || 'Prior Prescription'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 text-[11px] text-slate-400">
                  💡 <strong>Drug Reconciliation:</strong> All active prescriptions chronologically merged. The physician can edit, stop, or renew these with one click during consultation.
                </div>
              </div>
            )}

            {/* TAB 3: EXTRACTED LAB INVESTIGATIONS WITH OUT-OF-RANGE HIGHLIGHTS */}
            {activeTab === 'labs' && (
              <div className="space-y-3">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-700 text-slate-400 uppercase font-semibold">
                        <th className="py-2 px-2">Test Parameter</th>
                        <th className="py-2 px-2">Result Value</th>
                        <th className="py-2 px-2">Reference Range</th>
                        <th className="py-2 px-2">Clinical Flag</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {allLabResults.map((lab, idx) => (
                        <tr
                          key={idx}
                          className={`hover:bg-slate-900/60 ${
                            lab.isAbnormal ? 'bg-rose-950/20 text-white' : 'text-slate-300'
                          }`}
                        >
                          <td className="py-2 px-2 font-medium">{lab.testName}</td>
                          <td className="py-2 px-2 font-mono font-bold">
                            <span
                              className={
                                lab.isAbnormal
                                  ? 'text-rose-400 bg-rose-500/20 px-1.5 py-0.5 rounded'
                                  : 'text-slate-200'
                              }
                            >
                              {lab.resultValue} {lab.unit}
                            </span>
                          </td>
                          <td className="py-2 px-2 text-slate-400 font-mono">{lab.referenceRange}</td>
                          <td className="py-2 px-2">
                            {lab.isAbnormal ? (
                              <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-rose-600 text-white uppercase">
                                {lab.flagType || 'HIGH'}
                              </span>
                            ) : (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400">
                                Normal
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="bg-rose-950/30 border border-rose-500/40 rounded-xl p-3 text-xs text-rose-200">
                  ⚠️ <strong>Abnormal Value Trigger:</strong> HbA1c 9.2% & Creatinine 1.28 mg/dL automatically highlighted in red on the physician's EMR screen.
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={onBack}
              className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Intake</span>
            </button>

            <button
              id="btn-proceed-to-summary"
              type="button"
              onClick={onProceed}
              className="px-8 py-3.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold rounded-xl shadow-lg flex items-center gap-2 cursor-pointer transition-all"
            >
              <span>Generate Structured Clinical Summary (Step 4)</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
