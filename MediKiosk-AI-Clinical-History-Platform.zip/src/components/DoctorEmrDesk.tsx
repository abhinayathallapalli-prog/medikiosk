import React, { useState, useEffect } from 'react';
import { 
  Stethoscope, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  FileText, 
  Pill, 
  Activity, 
  ShieldCheck, 
  Printer, 
  Save, 
  Edit3, 
  ArrowLeft, 
  Sparkles, 
  HeartHandshake,
  TrendingDown,
  Building2,
  Share2,
  Plus
} from 'lucide-react';
import { PatientProfile, ClinicalHistoryRecord, LanguageCode } from '../types';
import { UI_TEXTS } from '../data/translations';

interface DoctorEmrDeskProps {
  patient: PatientProfile;
  record: ClinicalHistoryRecord;
  currentLanguage: LanguageCode;
  onBackToKiosk: () => void;
}

export const DoctorEmrDesk: React.FC<DoctorEmrDeskProps> = ({
  patient,
  record,
  currentLanguage,
  onBackToKiosk,
}) => {
  const t = UI_TEXTS[currentLanguage] || UI_TEXTS.en;

  // Editable Doctor's State
  const [chiefComplaint, setChiefComplaint] = useState(record.chiefComplaint);
  const [hpiSummary, setHpiSummary] = useState(
    `${record.chiefComplaint} for ${record.durationOfComplaint}. Site: ${record.hpi.site}. Character: ${record.hpi.character}. Radiation: ${record.hpi.radiation}. Severity: ${record.hpi.severity}/10. Aggravating factors: ${record.hpi.exacerbatingFactors}. Relieving factors: ${record.hpi.relievingFactors}. Associated with: ${record.hpi.associations.join(', ') || 'None'}.`
  );

  const [clinicalImpression, setClinicalImpression] = useState(
    patient.opdTrack === 'ayush'
      ? 'Sandhivata (Janu Sandhi) with Vata-Kapha Prakopa and Agnimandya. In view of elevated HbA1c (9.2%), advise strict Pathya Ahara and glycemic titration.'
      : 'Cardiovascular Evaluation: Retrosternal Chest Pain (R/O Acute Coronary Syndrome). Elevated HbA1c 9.2%, Mild Renal Impairment.'
  );

  const [rxMedicines, setRxMedicines] = useState<string[]>([
    patient.opdTrack === 'ayush' ? 'Tab Yogaraj Guggulu (500mg) 2 tab BD with warm water' : 'Tab Metformin 500mg BD after meals',
    patient.opdTrack === 'ayush' ? 'Dashamoola Kwatha 20ml BD with equal warm water' : 'Tab Telmisartan 40mg OD morning',
    patient.opdTrack === 'ayush' ? 'Mahanarayana Taila for local abhyanga BD' : 'Tab Atorvastatin 20mg HS bedtime',
  ]);
  const [newRxInput, setNewRxInput] = useState('');

  const [isSaved, setIsSaved] = useState(false);
  const [consultSeconds, setConsultSeconds] = useState(42);

  // Timer simulation to show how fast doctor reviews
  useEffect(() => {
    const timer = setInterval(() => {
      setConsultSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleAddMed = () => {
    if (!newRxInput.trim()) return;
    setRxMedicines([...rxMedicines, newRxInput.trim()]);
    setNewRxInput('');
  };

  const handleSaveToAbdm = () => {
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const hasEmergency = record.redFlags.length > 0;

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Top Clinical Banner */}
      <div className="bg-slate-800/95 border border-slate-700/90 rounded-2xl p-4 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBackToKiosk}
              className="p-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white cursor-pointer"
              title="Return to Kiosk"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-300 text-xs font-bold border border-teal-500/30 flex items-center gap-1">
                  <Stethoscope className="w-3.5 h-3.5" />
                  HIS Doctor Consultation Screen
                </span>
                <span className="text-xs text-slate-400">• Room 14 (AIIA Kayachikitsa OPD)</span>
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white mt-0.5">
                {patient.name} ({patient.age}y / {patient.gender.toUpperCase()})
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                ABHA: <span className="text-teal-300">{patient.abhaId}</span> • Token: <strong className="text-emerald-400">{patient.tokenNumber}</strong>
              </p>
            </div>
          </div>

          {/* Consultation Efficiency Metric */}
          <div className="flex items-center gap-3 bg-slate-950/80 border border-slate-800 rounded-xl p-3">
            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                Encounter Elapsed
              </span>
              <span className="text-lg font-mono font-bold text-emerald-400">
                00:{consultSeconds < 10 ? `0${consultSeconds}` : consultSeconds}
              </span>
            </div>
            <div className="h-8 w-px bg-slate-800"></div>
            <div>
              <span className="text-[10px] uppercase font-bold text-amber-400 flex items-center gap-1">
                <TrendingDown className="w-3 h-3" />
                Time Saved
              </span>
              <span className="text-xs font-semibold text-slate-200">
                ~10.5 mins history saved
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Red-Flag Warning Banner if Triggered */}
      {hasEmergency && (
        <div className="bg-red-950/80 border-2 border-red-500 rounded-2xl p-4 shadow-xl shadow-red-950/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-pulse">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-black text-red-100 uppercase tracking-wide">
                Priority Red-Flag Detected: {record.redFlags[0]?.symptom}
              </h4>
              <p className="text-xs text-red-200 mt-0.5">
                {record.redFlags[0]?.triggerReason} • {record.redFlags[0]?.actionRequired}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => alert('Emergency alert acknowledged. 12-lead ECG dispatched.')}
            className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-xl shadow cursor-pointer shrink-0"
          >
            Acknowledge & Order ECG
          </button>
        </div>
      )}

      {/* Main 2-Column Doctor Desk */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: AI-Synthesized History & Dashavidha Matrix */}
        <div className="lg:col-span-7 space-y-5">
          {/* Card 1: HPI & Chief Complaint (Physician Verified Draft) */}
          <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
              <span className="text-xs font-bold text-teal-300 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-4 h-4" />
                1. AI Clinical History Intake Summary (SOCRATES)
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono">
                Editable Draft
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Chief Complaint:
              </label>
              <input
                type="text"
                value={chiefComplaint}
                onChange={(e) => setChiefComplaint(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white focus:border-teal-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                History of Present Illness (HPI):
              </label>
              <textarea
                rows={4}
                value={hpiSummary}
                onChange={(e) => setHpiSummary(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs text-slate-200 leading-relaxed focus:border-teal-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950/60 p-3 rounded-xl border border-slate-800">
              <div>
                <span className="text-slate-400 block text-[11px]">Past Medical History:</span>
                <span className="text-slate-200 font-medium">{record.pastMedicalHistory.join(', ') || 'Nil'}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Allergies:</span>
                <span className="text-emerald-400 font-medium">{record.drugAllergies.join(', ')}</span>
              </div>
            </div>
          </div>

          {/* Card 2: AYUSH Dashavidha Pariksha Matrix (AIIA Protocol) */}
          {record.ayushAssessment && (
            <div className="bg-amber-950/20 border border-amber-500/40 rounded-2xl p-5 shadow-xl space-y-3">
              <div className="flex items-center justify-between border-b border-amber-500/30 pb-2">
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  2. Dashavidha Pariksha (दशविध परीक्षा मैट्रिक्स)
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-semibold">
                  AIIA Ayurveda Engine
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">प्रकृति (Prakriti)</span>
                  <span className="text-xs font-bold text-amber-300">{record.ayushAssessment.prakriti}</span>
                </div>
                <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">अग्नि (Agni)</span>
                  <span className="text-xs font-bold text-amber-300">{record.ayushAssessment.agni}</span>
                </div>
                <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">कोष्ठ (Koshtha)</span>
                  <span className="text-xs font-bold text-amber-300">{record.ayushAssessment.koshtha}</span>
                </div>
                <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">सार / संहनन</span>
                  <span className="text-xs font-bold text-amber-300">{record.ayushAssessment.sara} / {record.ayushAssessment.samhanana}</span>
                </div>
              </div>

              <div className="bg-slate-900/90 p-3 rounded-xl border border-slate-800 space-y-1 text-xs">
                <span className="text-[11px] font-bold text-amber-400 block">
                  विकृति एवं संप्राप्ति (Doshic Pathogenesis):
                </span>
                <p className="text-slate-300 leading-relaxed">
                  {record.ayushAssessment.vikriti}. Low Jarana Shakti with irregular bowel habits (Krura Koshtha) leading to Ama accumulation at Janu Sandhi.
                </p>
                <div className="pt-1 text-[11px] text-slate-400 flex items-center gap-2">
                  <span>पथ्य-अपथ्य: Avoid curd, cold water, dry bakery food. Advise warm ginger water.</span>
                </div>
              </div>
            </div>
          )}

          {/* Card 3: Digitized Prior Records & Timeline */}
          <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-teal-400" />
                3. Prior Medical Records Timeline ({record.documents.length} Files)
              </span>
              <span className="text-[10px] text-emerald-400 font-mono">Digitized by Kiosk</span>
            </div>

            <div className="space-y-2">
              {record.documents.map((doc) => (
                <div key={doc.id} className="p-2.5 bg-slate-900/80 border border-slate-800 rounded-xl text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <strong className="text-white">{doc.name}</strong>
                    <span className="text-[10px] text-slate-400 font-mono">{doc.date}</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">{doc.extractedText.slice(0, 140)}...</p>
                  {doc.extractedLabResults.some((l) => l.isAbnormal) && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {doc.extractedLabResults
                        .filter((l) => l.isAbnormal)
                        .map((ab, i) => (
                          <span key={i} className="text-[10px] bg-rose-600/30 text-rose-300 border border-rose-500/30 px-1.5 py-0.5 rounded font-bold">
                            ⚠️ {ab.testName}: {ab.resultValue} {ab.unit} ({ab.flagType})
                          </span>
                        ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Doctor's Clinical Plan, Prescription & ABDM Actions */}
        <div className="lg:col-span-5 space-y-5">
          {/* Clinical Impression */}
          <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
              <span className="text-xs font-bold text-teal-300 uppercase tracking-wider flex items-center gap-1.5">
                <Edit3 className="w-4 h-4" />
                Clinical Impression & Assessment
              </span>
              <span className="text-[10px] text-slate-400">Physician Control</span>
            </div>

            <textarea
              rows={4}
              value={clinicalImpression}
              onChange={(e) => setClinicalImpression(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs text-slate-100 font-medium leading-relaxed focus:border-teal-500 outline-none"
            />
          </div>

          {/* Rx Prescription Pad */}
          <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <Pill className="w-4 h-4" />
                OPD Prescription (Rx)
              </span>
              <span className="text-[10px] text-slate-400">ABDM Linked</span>
            </div>

            <div className="space-y-2">
              {rxMedicines.map((rx, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-slate-900/90 border border-slate-800 text-xs text-slate-200">
                  <div className="flex items-center gap-2">
                    <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px] font-bold">
                      {idx + 1}
                    </span>
                    <span>{rx}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setRxMedicines(rxMedicines.filter((_, i) => i !== idx))}
                    className="text-slate-500 hover:text-rose-400 text-xs px-1"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>

            {/* Add Medicine input */}
            <div className="flex gap-2 pt-1">
              <input
                type="text"
                value={newRxInput}
                onChange={(e) => setNewRxInput(e.target.value)}
                placeholder="Add formulation / drug name..."
                onKeyDown={(e) => e.key === 'Enter' && handleAddMed()}
                className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-teal-500"
              />
              <button
                type="button"
                onClick={handleAddMed}
                className="px-3 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
          </div>

          {/* ABDM Actions & Print */}
          <div className="bg-slate-900/90 border border-slate-700/80 rounded-2xl p-5 shadow-xl space-y-3">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              Finalize Encounter & ABDM Health Locker Push
            </span>

            {isSaved && (
              <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Encounter signed. Clinical history & prescription synced to ABHA: {patient.abhaId}.</span>
              </div>
            )}

            <div className="space-y-2">
              <button
                id="btn-save-abdm"
                type="button"
                onClick={handleSaveToAbdm}
                className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Approve History & Push to ABDM PHR</span>
              </button>

              <button
                type="button"
                onClick={() => window.print()}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer border border-slate-700"
              >
                <Printer className="w-4 h-4" />
                <span>Print AIIA OPD Prescription Slip</span>
              </button>

              <button
                type="button"
                onClick={onBackToKiosk}
                className="w-full py-2 bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-slate-200 text-xs rounded-xl cursor-pointer"
              >
                Return to Patient Kiosk (Ready for Next Patient)
              </button>
            </div>

            <div className="pt-2 text-[10px] text-slate-500 text-center flex items-center justify-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>Digital Personal Data Protection Act 2023 Compliant</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
