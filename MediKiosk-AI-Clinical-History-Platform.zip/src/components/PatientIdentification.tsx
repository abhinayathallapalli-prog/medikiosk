import React, { useState } from 'react';
import { 
  CreditCard, 
  QrCode, 
  UserCheck, 
  ShieldCheck, 
  Volume2, 
  CheckCircle2, 
  ArrowRight, 
  Building2, 
  HeartHandshake, 
  FileText,
  ScanLine,
  Check,
  UserPlus
} from 'lucide-react';
import { PatientProfile, LanguageCode, OPDTrack } from '../types';
import { DEMO_PATIENTS } from '../data/clinicalKnowledge';
import { UI_TEXTS } from '../data/translations';
import { speakPrompt } from '../utils/speechHelper';

interface PatientIdentificationProps {
  currentLanguage: LanguageCode;
  onPatientIdentified: (patient: PatientProfile) => void;
  audioEnabled: boolean;
}

export const PatientIdentification: React.FC<PatientIdentificationProps> = ({
  currentLanguage,
  onPatientIdentified,
  audioEnabled,
}) => {
  const t = UI_TEXTS[currentLanguage] || UI_TEXTS.en;

  const [inputMode, setInputMode] = useState<'abha' | 'qr' | 'guest'>('abha');
  const [abhaInput, setAbhaInput] = useState('91-4523-8891-2304');
  const [patientName, setPatientName] = useState('Rajendra Prasad Sharma');
  const [age, setAge] = useState(58);
  const [gender, setGender] = useState<'male' | 'female' | 'other'>('male');
  const [phone, setPhone] = useState('+91 98102 45892');
  const [opdTrack, setOpdTrack] = useState<OPDTrack>('ayush');
  const [department, setDepartment] = useState('Kayachikitsa (Internal Medicine & Ayurveda)');

  // Granular DPDP Consent
  const [consentVoiceTouch, setConsentVoiceTouch] = useState(true);
  const [consentOcr, setConsentOcr] = useState(true);
  const [consentAbdm, setConsentAbdm] = useState(true);

  const [isScanningQr, setIsScanningQr] = useState(false);

  const playConsentAudio = () => {
    const consentSpeechText = currentLanguage === 'hi'
      ? 'डिजिटल व्यक्तिगत डेटा संरक्षण अधिनियम के तहत, हम आपकी आवाज़ और रिपोर्ट केवल डॉक्टर के परामर्श और आभा रिकॉर्ड के लिए सुरक्षित रखेंगे। क्या आप सहमत हैं?'
      : 'Under the Digital Personal Data Protection Act, we securely record your symptoms and medical documents solely for clinical care and ABDM exchange. Do you consent?';
    speakPrompt(consentSpeechText, currentLanguage);
  };

  const handleSelectDemo = (demo: PatientProfile) => {
    setAbhaInput(demo.abhaId);
    setPatientName(demo.name);
    setAge(demo.age);
    setGender(demo.gender);
    setPhone(demo.phone);
    setOpdTrack(demo.opdTrack);
    setDepartment(demo.department);
    if (audioEnabled) {
      speakPrompt(`${demo.name}, स्वागत है।`, currentLanguage);
    }
  };

  const handleScanQrSimulation = () => {
    setIsScanningQr(true);
    setTimeout(() => {
      setIsScanningQr(false);
      const demo = DEMO_PATIENTS[0];
      handleSelectDemo(demo);
    }, 1200);
  };

  const handleProceed = () => {
    const newProfile: PatientProfile = {
      id: `pat-${Date.now().toString().slice(-6)}`,
      abhaId: abhaInput.trim() || '91-0000-0000-0000',
      name: patientName.trim() || 'Guest Patient',
      age: Number(age) || 45,
      gender,
      phone: phone || '+91 90000 00000',
      address: 'Sarita Vihar, New Delhi',
      district: 'South East Delhi',
      state: 'Delhi',
      tokenNumber: opdTrack === 'ayush' ? `AIIA-AYU-${Math.floor(100 + Math.random() * 900)}` : `AIIA-GEN-${Math.floor(100 + Math.random() * 900)}`,
      department: opdTrack === 'ayush' ? 'Kayachikitsa (Internal Medicine & Ayurveda)' : 'General OPD & Internal Medicine',
      opdTrack,
      isAyushSpecific: opdTrack === 'ayush',
      registeredAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      consentGranted: consentVoiceTouch && consentOcr && consentAbdm,
      consentTimestamp: new Date().toISOString(),
    };

    onPatientIdentified(newProfile);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold border border-emerald-500/30">
              <Building2 className="w-3.5 h-3.5" />
              <span>{t.ministryBadge}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {t.welcomeGreeting}
            </h2>
            <p className="text-sm sm:text-base text-slate-300 max-w-2xl">
              {t.welcomeSub}
            </p>
          </div>

          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 text-center shrink-0 w-full md:w-auto">
            <span className="text-[11px] text-slate-400 block font-medium">OPD Registration Desk</span>
            <span className="text-lg font-bold text-emerald-400 font-mono">KIOSK #04</span>
            <span className="text-[10px] text-slate-500 block">Avg. history time: 3.2 mins</span>
          </div>
        </div>
      </div>

      {/* Quick Load Demo Patients (For instant testability) */}
      <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <UserCheck className="w-4 h-4" />
            Quick Test Demonstration Profiles (Click to Load):
          </span>
          <span className="text-[11px] text-slate-400">One-click auto-fill for evaluation</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {DEMO_PATIENTS.map((demo) => (
            <button
              key={demo.id}
              type="button"
              onClick={() => handleSelectDemo(demo)}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                abhaInput === demo.abhaId
                  ? 'bg-emerald-950/80 border-emerald-500/80 shadow-md ring-1 ring-emerald-500/50'
                  : 'bg-slate-900/80 border-slate-700/80 hover:border-slate-600 hover:bg-slate-850'
              }`}
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-white text-sm">{demo.name}</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                    {demo.age}y / {demo.gender === 'male' ? 'M' : 'F'}
                  </span>
                </div>
                <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                  <span>ABHA: {demo.abhaId}</span>
                  <span>•</span>
                  <span className={demo.opdTrack === 'ayush' ? 'text-amber-400 font-medium' : 'text-teal-400'}>
                    {demo.opdTrack === 'ayush' ? 'AIIA Ayush Track' : 'Allopathic Track'}
                  </span>
                </div>
              </div>
              {abhaInput === demo.abhaId && (
                <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0">
                  <Check className="w-4 h-4" />
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Main Identification Mode Tabs */}
      <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-6 shadow-xl space-y-6">
        <div className="flex items-center justify-between border-b border-slate-700/80 pb-4">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-emerald-400" />
            <span>Step 1: Patient Identity & ABHA Verification</span>
          </h3>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setInputMode('abha')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                inputMode === 'abha' ? 'bg-emerald-600 text-white' : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Enter ABHA ID
            </button>
            <button
              type="button"
              onClick={() => setInputMode('qr')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                inputMode === 'qr' ? 'bg-emerald-600 text-white' : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Scan QR / Card
            </button>
            <button
              type="button"
              onClick={() => setInputMode('guest')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                inputMode === 'guest' ? 'bg-emerald-600 text-white' : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
              }`}
            >
              New Registration
            </button>
          </div>
        </div>

        {/* Input Details */}
        {inputMode === 'qr' ? (
          <div className="p-8 border-2 border-dashed border-slate-600 rounded-2xl bg-slate-900/60 text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-slate-800 mx-auto flex items-center justify-center text-emerald-400">
              <QrCode className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <h4 className="font-semibold text-white">Scan Patient ABHA Card or Ayushman App QR</h4>
              <p className="text-xs text-slate-400 mt-1">
                Hold your physical ABHA card or smartphone screen in front of the kiosk optical scanner.
              </p>
            </div>
            <button
              type="button"
              onClick={handleScanQrSimulation}
              disabled={isScanningQr}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl text-sm shadow-lg flex items-center gap-2 mx-auto cursor-pointer"
            >
              <ScanLine className="w-4 h-4" />
              <span>{isScanningQr ? 'Reading optical QR code...' : 'Simulate QR Code Scan'}</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                ABHA Number (14-Digit Ayushman Bharat ID)
              </label>
              <div className="relative">
                <input
                  id="input-abha-id"
                  type="text"
                  value={abhaInput}
                  onChange={(e) => setAbhaInput(e.target.value)}
                  placeholder="e.g. 91-4523-8891-2304"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm font-mono text-emerald-300 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
                />
                <span className="absolute right-3 top-2.5 text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold">
                  ABDM Verified
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Patient Full Name (रोगी का नाम)
              </label>
              <input
                id="input-patient-name"
                type="text"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                placeholder="Full Name"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Age (आयु)
                </label>
                <input
                  id="input-patient-age"
                  type="number"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:border-emerald-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Gender (लिंग)
                </label>
                <select
                  id="select-patient-gender"
                  value={gender}
                  onChange={(e) => setGender(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:border-emerald-500 outline-none"
                >
                  <option value="male">Male (पुरुष)</option>
                  <option value="female">Female (महिला)</option>
                  <option value="other">Other (अन्य)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Mobile Number (Linked with ABHA)
              </label>
              <input
                id="input-patient-phone"
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:border-emerald-500 outline-none"
              />
            </div>
          </div>
        )}

        {/* OPD Track Selection (AIIA Ayush vs Allopathic) */}
        <div className="pt-2">
          <label className="block text-xs font-bold text-slate-200 uppercase tracking-wider mb-2">
            Select OPD Clinical Pathway (क्लिनिकल विभाग चुनें)
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => {
                setOpdTrack('ayush');
                setDepartment('Kayachikitsa (Internal Medicine & Ayurveda)');
              }}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                opdTrack === 'ayush'
                  ? 'bg-amber-950/40 border-amber-500 shadow-md ring-1 ring-amber-500/50'
                  : 'bg-slate-900/60 border-slate-700 hover:border-slate-600'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-amber-300 text-sm flex items-center gap-1.5">
                  🌿 AIIA Ayurvedic OPD Track
                </span>
                {opdTrack === 'ayush' && (
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 font-semibold px-2 py-0.5 rounded">
                    Selected
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Includes <strong>Dashavidha Pariksha</strong> (Prakriti, Vikriti, Agni, Koshtha, Ahara-Vihara) for comprehensive Ayurvedic diagnosis.
              </p>
            </button>

            <button
              type="button"
              onClick={() => {
                setOpdTrack('allopathic');
                setDepartment('General Medicine & Surgical OPD');
              }}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                opdTrack === 'allopathic'
                  ? 'bg-teal-950/40 border-teal-500 shadow-md ring-1 ring-teal-500/50'
                  : 'bg-slate-900/60 border-slate-700 hover:border-slate-600'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-teal-300 text-sm flex items-center gap-1.5">
                  🏥 General Allopathic OPD Track
                </span>
                {opdTrack === 'allopathic' && (
                  <span className="text-[10px] bg-teal-500/20 text-teal-300 font-semibold px-2 py-0.5 rounded">
                    Selected
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Standard clinical protocol with <strong>SOCRATES HPI</strong>, past medical/surgical history, drug allergies, and review of systems.
              </p>
            </button>
          </div>
        </div>

        {/* DPDP Act 2023 & ABDM Consent Module */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                  {t.consentTitle}
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Strict privacy compliance with ABDM Health Data Management Policy.
                </p>
              </div>
            </div>

            {/* Audio Explanation Button */}
            <button
              type="button"
              onClick={playConsentAudio}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5 border border-slate-700 cursor-pointer"
            >
              <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>सहमति सुनें (Audio)</span>
            </button>
          </div>

          <div className="space-y-2 pt-1">
            <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-300">
              <input
                type="checkbox"
                checked={consentVoiceTouch}
                onChange={(e) => setConsentVoiceTouch(e.target.checked)}
                className="mt-0.5 rounded accent-emerald-500"
              />
              <span>
                <strong>Multimodal Clinical History Elicitation:</strong> I consent to AI speech recognition and touch-based intake to prepare my clinical history.
              </span>
            </label>

            <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-300">
              <input
                type="checkbox"
                checked={consentOcr}
                onChange={(e) => setConsentOcr(e.target.checked)}
                className="mt-0.5 rounded accent-emerald-500"
              />
              <span>
                <strong>Document OCR Processing:</strong> I consent to OCR scanning of my paper prescriptions and lab reports for doctor review.
              </span>
            </label>

            <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-300">
              <input
                type="checkbox"
                checked={consentAbdm}
                onChange={(e) => setConsentAbdm(e.target.checked)}
                className="mt-0.5 rounded accent-emerald-500"
              />
              <span>
                <strong>ABDM Health Locker Interoperability:</strong> Link this clinical summary to my ABHA ID for hospital EMR continuity.
              </span>
            </label>
          </div>

          <p className="text-[10px] text-slate-500 italic pt-1">
            * Temporary kiosk session data is immediately purged upon submission. You retain the right to withdraw consent at any time.
          </p>
        </div>

        {/* Action Button */}
        <div className="flex items-center justify-end pt-2">
          <button
            id="btn-proceed-to-converse"
            type="button"
            onClick={handleProceed}
            disabled={!consentVoiceTouch || !patientName.trim()}
            className="px-8 py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-950/60 flex items-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            <span>{t.startIntake}</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
