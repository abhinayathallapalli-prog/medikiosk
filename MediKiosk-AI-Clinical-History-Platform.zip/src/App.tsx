import React, { useState } from 'react';
import { 
  Header 
} from './components/Header';
import { 
  PatientIdentification 
} from './components/PatientIdentification';
import { 
  ConversationalIntake 
} from './components/ConversationalIntake';
import { 
  DocumentScanner 
} from './components/DocumentScanner';
import { 
  SummaryRouting 
} from './components/SummaryRouting';
import { 
  DoctorEmrDesk 
} from './components/DoctorEmrDesk';
import { 
  RedFlagModal 
} from './components/RedFlagModal';
import { 
  PatientProfile, 
  ClinicalHistoryRecord, 
  LanguageCode, 
  MedicalDocument, 
  RedFlagAlert 
} from './types';
import { 
  DEMO_PATIENTS, 
  INITIAL_SAMPLE_DOCUMENTS, 
  DEFAULT_AYUSH_PARIKSHA 
} from './data/clinicalKnowledge';
import { 
  Building2, 
  CheckCircle2, 
  ArrowRight, 
  Sparkles, 
  Download, 
  ShieldCheck, 
  Clock,
  HeartHandshake
} from 'lucide-react';
import { generateProjectZip, triggerDownload } from './utils/zipExporter';

export default function App() {
  // Navigation & View State
  const [activeView, setActiveView] = useState<'kiosk' | 'doctor'>('kiosk');
  const [kioskStep, setKioskStep] = useState<1 | 2 | 3 | 4>(1);

  // Internationalization & Audio State
  const [currentLanguage, setCurrentLanguage] = useState<LanguageCode>('hi');
  const [audioEnabled, setAudioEnabled] = useState<boolean>(true);

  // Active Patient State
  const [currentPatient, setCurrentPatient] = useState<PatientProfile>(DEMO_PATIENTS[0]);

  // Digitized Documents State
  const [documents, setDocuments] = useState<MedicalDocument[]>(INITIAL_SAMPLE_DOCUMENTS);

  // Active Red Flag Alert
  const [redFlagAlert, setRedFlagAlert] = useState<RedFlagAlert | null>(null);

  // Complete Clinical Record State
  const [clinicalRecord, setClinicalRecord] = useState<ClinicalHistoryRecord>({
    chiefComplaint: 'Joint Pain & Swelling (Sandhivata / Arthritis)',
    durationOfComplaint: '6 months (worsening over last 2 weeks)',
    hpi: {
      site: 'Bilateral Knees (Janu Sandhi)',
      onset: 'Gradual onset with morning stiffness',
      character: 'Dull throbbing pain with crepitus on weight-bearing',
      radiation: 'Non-radiating',
      associations: ['Morning stiffness > 45 mins', 'Swelling after standing'],
      timing: 'Worst on waking and after long walks',
      exacerbatingFactors: 'Cold climate, stairs climbing, dry diet',
      relievingFactors: 'Warm mustard oil massage & hot water fomentation',
      severity: 7,
    },
    pastMedicalHistory: [
      'Type 2 Diabetes Mellitus (Diagnosed 2018)',
      'Essential Hypertension (on Telmisartan 40mg)',
    ],
    pastSurgicalHistory: ['No major surgeries reported'],
    drugAllergies: ['No Known Drug Allergies (NKDA)'],
    foodAllergies: ['None'],
    currentMedications: INITIAL_SAMPLE_DOCUMENTS[0].extractedMedications,
    familyHistory: ['Father: Osteoarthritis and CAD', 'Mother: Type 2 Diabetes'],
    personalHistory: {
      smoking: 'Never',
      alcohol: 'Never',
      diet: 'Vegetarian with high spices',
      physicalActivity: 'Sedentary',
    },
    reviewOfSystems: [
      { system: 'Musculoskeletal', symptoms: ['Janu sandhishoola', 'Stiffness'], isPositive: true },
      { system: 'Endocrine/Metabolic', symptoms: ['Elevated blood glucose'], isPositive: true },
      { system: 'Gastrointestinal', symptoms: ['Agnimandya', 'Krura Koshtha'], isPositive: true },
    ],
    ayushAssessment: DEFAULT_AYUSH_PARIKSHA,
    redFlags: [],
    documents: INITIAL_SAMPLE_DOCUMENTS,
    verifiedByPhysician: false,
  });

  // Handle Step 1 Complete
  const handlePatientIdentified = (patient: PatientProfile) => {
    setCurrentPatient(patient);
    setClinicalRecord((prev) => ({
      ...prev,
      ayushAssessment: patient.opdTrack === 'ayush' ? DEFAULT_AYUSH_PARIKSHA : undefined,
    }));
    setKioskStep(2);
  };

  // Handle Step 2 Complete
  const handleConversationalIntakeComplete = (intakeData: Partial<ClinicalHistoryRecord>) => {
    setClinicalRecord((prev) => ({
      ...prev,
      ...intakeData,
      currentMedications: documents.flatMap((d) => d.extractedMedications),
      documents,
    }));
    setKioskStep(3);
  };

  // Handle Step 3 Complete
  const handleDocumentScanningComplete = () => {
    setClinicalRecord((prev) => ({
      ...prev,
      documents,
      currentMedications: documents.flatMap((d) => d.extractedMedications),
    }));
    setKioskStep(4);
  };

  // Handle Red Flag
  const handleRedFlagTriggered = (alert: RedFlagAlert) => {
    setRedFlagAlert(alert);
    setClinicalRecord((prev) => ({
      ...prev,
      redFlags: [alert, ...prev.redFlags],
    }));
  };

  // Reset to start a new patient
  const handleResetNewPatient = () => {
    setCurrentPatient({
      ...DEMO_PATIENTS[1],
      id: `pat-${Date.now().toString().slice(-4)}`,
      tokenNumber: `AIIA-OPD-${Math.floor(100 + Math.random() * 900)}`,
    });
    setKioskStep(1);
    setActiveView('kiosk');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Global Header */}
      <Header
        currentLanguage={currentLanguage}
        onLanguageChange={setCurrentLanguage}
        activeView={activeView}
        onViewChange={setActiveView}
        audioEnabled={audioEnabled}
        onToggleAudio={() => setAudioEnabled(!audioEnabled)}
        activeToken={currentPatient.tokenNumber}
        hasRedFlag={clinicalRecord.redFlags.length > 0}
      />

      {/* Main Content Area */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
        {/* If in Kiosk Mode: Show Stepper Bar */}
        {activeView === 'kiosk' && (
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3 shadow-lg flex items-center justify-between overflow-x-auto">
            <div className="flex items-center gap-2 sm:gap-4 min-w-max">
              {[
                { step: 1, label: '1. Identify & Consent', sub: 'ABHA & DPDP' },
                { step: 2, label: '2. Voice & Touch Intake', sub: 'SOCRATES / Ayush' },
                { step: 3, label: '3. Scan Documents', sub: 'OCR & Timeline' },
                { step: 4, label: '4. Summary & Route', sub: 'ABDM & Token' },
              ].map((item) => {
                const isActive = kioskStep === item.step;
                const isPassed = kioskStep > item.step;
                return (
                  <button
                    key={item.step}
                    type="button"
                    onClick={() => setKioskStep(item.step as any)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-xl text-left transition-all cursor-pointer ${
                      isActive
                        ? 'bg-emerald-600 text-white shadow-md'
                        : isPassed
                        ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`}
                  >
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                        isActive
                          ? 'bg-white text-emerald-900'
                          : isPassed
                          ? 'bg-emerald-500 text-white'
                          : 'bg-slate-700 text-slate-300'
                      }`}
                    >
                      {item.step}
                    </div>
                    <div>
                      <span className="block text-xs font-bold leading-tight">{item.label}</span>
                      <span className="block text-[10px] opacity-80">{item.sub}</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Quick jump to Doctor View button */}
            <div className="hidden md:flex items-center gap-2 pl-4 border-l border-slate-800">
              <button
                type="button"
                onClick={() => setActiveView('doctor')}
                className="px-3 py-1.5 rounded-lg bg-teal-950 border border-teal-500/50 text-teal-300 hover:bg-teal-900 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <span>Switch to Doctor View</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* View Routing */}
        {activeView === 'kiosk' ? (
          <>
            {kioskStep === 1 && (
              <PatientIdentification
                currentLanguage={currentLanguage}
                onPatientIdentified={handlePatientIdentified}
                audioEnabled={audioEnabled}
              />
            )}

            {kioskStep === 2 && (
              <ConversationalIntake
                patient={currentPatient}
                currentLanguage={currentLanguage}
                audioEnabled={audioEnabled}
                onComplete={handleConversationalIntakeComplete}
                onRedFlagTriggered={handleRedFlagTriggered}
                onBackToProfile={() => setKioskStep(1)}
              />
            )}

            {kioskStep === 3 && (
              <DocumentScanner
                documents={documents}
                onUpdateDocuments={setDocuments}
                currentLanguage={currentLanguage}
                onProceed={handleDocumentScanningComplete}
                onBack={() => setKioskStep(2)}
              />
            )}

            {kioskStep === 4 && (
              <SummaryRouting
                patient={currentPatient}
                record={clinicalRecord}
                currentLanguage={currentLanguage}
                audioEnabled={audioEnabled}
                onGoToDoctorDesk={() => setActiveView('doctor')}
                onResetForNewPatient={handleResetNewPatient}
              />
            )}
          </>
        ) : (
          /* Doctor EMR Consultation Desk View */
          <DoctorEmrDesk
            patient={currentPatient}
            record={clinicalRecord}
            currentLanguage={currentLanguage}
            onBackToKiosk={() => setActiveView('kiosk')}
          />
        )}
      </main>

      {/* Emergency Red-Flag Modal Alert */}
      <RedFlagModal
        alert={redFlagAlert}
        onClose={() => setRedFlagAlert(null)}
        onDispatchEmergency={() => {
          setRedFlagAlert(null);
          setActiveView('doctor');
        }}
      />

      {/* Footer with Compliance & Ayush Attribution */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 text-xs py-4 px-4 mt-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              <strong>MediKiosk</strong> • All India Institute of Ayurveda (AIIA), New Delhi • Ministry of Ayush, Govt. of India
            </span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span className="text-emerald-400 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              ABDM & DPDP Act 2023 Compliant
            </span>
            <span className="text-slate-600">|</span>
            <span>Bhashini Multilingual Speech Engine</span>
            <span className="text-slate-600">|</span>
            <button
              type="button"
              onClick={async () => {
                const blob = await generateProjectZip();
                triggerDownload(blob, 'MediKiosk-Clinical-Intake-Platform.zip');
              }}
              className="text-amber-400 hover:underline flex items-center gap-1 cursor-pointer font-semibold"
            >
              <Download className="w-3 h-3" />
              <span>Download ZIP</span>
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
