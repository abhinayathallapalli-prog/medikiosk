export type LanguageCode = 'hi' | 'en' | 'mr' | 'ta' | 'bn' | 'te' | 'gu';

export interface LanguageOption {
  code: LanguageCode;
  label: string;
  nativeLabel: string;
  voiceCode: string;
}

export type OPDTrack = 'allopathic' | 'ayush';

export interface PatientProfile {
  id: string;
  abhaId: string;
  name: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  phone: string;
  address: string;
  district: string;
  state: string;
  photoUrl?: string;
  tokenNumber: string;
  department: string;
  opdTrack: OPDTrack;
  isAyushSpecific: boolean;
  registeredAt: string;
  consentGranted: boolean;
  consentTimestamp?: string;
}

export interface SocratesHPI {
  site: string;
  onset: string;
  character: string;
  radiation: string;
  associations: string[];
  timing: string;
  exacerbatingFactors: string;
  relievingFactors: string;
  severity: number; // 1-10
}

export interface DashavidhaPariksha {
  prakriti: 'Vata' | 'Pitta' | 'Kapha' | 'Vata-Pitta' | 'Pitta-Kapha' | 'Vata-Kapha' | 'Tridoshaja';
  vikriti: string;
  sara: 'Pravara' | 'Madhyama' | 'Avara'; // Tissue excellence
  samhanana: 'Susamhata' | 'Madhyama' | 'Hina'; // Body build/compactness
  pramana: 'Sama' | 'Hina' | 'Ati'; // Anthropometry
  satmya: 'Sarva-rasa' | 'Eka-rasa' | 'Madhyama'; // Adaptability
  sattva: 'Pravara' | 'Madhyama' | 'Avara'; // Mental resilience
  aharaShakti: {
    abhyavaharana: 'Uttama' | 'Madhyama' | 'Hina'; // Ingestion
    jarana: 'Uttama' | 'Madhyama' | 'Hina'; // Digestion
  };
  vyayamaShakti: 'Uttama' | 'Madhyama' | 'Hina'; // Physical work capacity
  vaya: 'Bala' | 'Madhya' | 'Jirna'; // Age group
  agni: 'Sama' | 'Vishama' | 'Tikshna' | 'Manda';
  koshtha: 'Mridu' | 'Madhyama' | 'Krura';
  aharaVihara: {
    dietType: 'Shakahari (Veg)' | 'Mishrahari (Non-Veg)' | 'Alpahari';
    sleepPattern: 'Samyak (Normal)' | 'Anidra (Insomnia)' | 'Atinidra (Excessive)';
    dailyRoutine: string;
  };
}

export interface RedFlagAlert {
  id: string;
  severity: 'CRITICAL_EMERGENCY' | 'URGENT_PRIORITY' | 'STANDARD';
  symptom: string;
  triggerReason: string;
  actionRequired: string;
  timestamp: string;
  acknowledged: boolean;
}

export interface ExtractedMedication {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  prescribedBy?: string;
  datePrescribed?: string;
}

export interface ExtractedLabResult {
  testName: string;
  resultValue: string;
  unit: string;
  referenceRange: string;
  isAbnormal: boolean;
  flagType?: 'HIGH' | 'LOW' | 'CRITICAL';
}

export interface MedicalDocument {
  id: string;
  name: string;
  documentType: 'Prescription' | 'Lab Report' | 'Discharge Summary' | 'Radiology / X-Ray';
  date: string;
  hospitalName: string;
  fileSize: string;
  thumbnailUrl?: string;
  ocrStatus: 'completed' | 'processing' | 'queued';
  extractedText: string;
  extractedDiagnoses: string[];
  extractedMedications: ExtractedMedication[];
  extractedLabResults: ExtractedLabResult[];
  notes: string;
  abnormalWarnings: string[];
}

export interface ClinicalHistoryRecord {
  chiefComplaint: string;
  durationOfComplaint: string;
  hpi: SocratesHPI;
  pastMedicalHistory: string[];
  pastSurgicalHistory: string[];
  drugAllergies: string[];
  foodAllergies: string[];
  currentMedications: ExtractedMedication[];
  familyHistory: string[];
  personalHistory: {
    smoking: 'Never' | 'Former' | 'Active';
    alcohol: 'Never' | 'Occasional' | 'Regular';
    diet: string;
    physicalActivity: 'Sedentary' | 'Moderate' | 'Active';
  };
  reviewOfSystems: {
    system: string;
    symptoms: string[];
    isPositive: boolean;
  }[];
  ayushAssessment?: DashavidhaPariksha;
  redFlags: RedFlagAlert[];
  documents: MedicalDocument[];
  physicianNotes?: string;
  verifiedByPhysician: boolean;
  fhirBundleId?: string;
}

export interface ConversationTurn {
  id: string;
  sender: 'ai' | 'patient';
  text: string;
  audioPrompt?: string;
  stepKey?: string;
  options?: {
    label: string;
    subLabel?: string;
    value: string;
    icon?: string;
    isRedFlag?: boolean;
  }[];
  timestamp: string;
}
